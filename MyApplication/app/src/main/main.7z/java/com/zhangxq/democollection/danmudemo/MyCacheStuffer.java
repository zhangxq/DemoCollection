package com.zhangxq.democollection.danmudemo;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.TextPaint;

import java.util.HashMap;
import java.util.Map;

import master.flame.danmaku.danmaku.model.BaseDanmaku;
import master.flame.danmaku.danmaku.model.android.BaseCacheStuffer;
import master.flame.danmaku.danmaku.model.android.SimpleTextCacheStuffer;

/**
 * Created by zhangxiaoqi on 2016/7/26.
 */
public class MyCacheStuffer extends BaseCacheStuffer {

    private final static Map<Float, Float> sTextHeightCache = new HashMap<Float, Float>();

    protected Float getCacheHeight(BaseDanmaku danmaku, Paint paint) {
        Float textSize = paint.getTextSize();
        Float textHeight = sTextHeightCache.get(textSize);
        if (textHeight == null) {
            Paint.FontMetrics fontMetrics = paint.getFontMetrics();
            textHeight = fontMetrics.descent - fontMetrics.ascent + fontMetrics.leading;
            sTextHeightCache.put(textSize, textHeight);
        }
        return textHeight;
    }

    @Override
    public void measure(BaseDanmaku danmaku, TextPaint paint, boolean fromWorkerThread) {
//        float w = 0;
//        Float textHeight = 0f;
//        textHeight = getCacheHeight(danmaku, paint);
//        for (String tempStr : danmaku.) {
//            if (tempStr.length() > 0) {
//                float tr = paint.measureText(tempStr);
//                w = Math.max(tr, w);
//            }
//        }
        danmaku.paintWidth = 700;
        danmaku.paintHeight = 130;
    }

    @Override
    public void drawStroke(BaseDanmaku danmaku, String lineText, Canvas canvas, float left, float top, Paint paint) {

    }

    @Override
    public void drawText(BaseDanmaku danmaku, String lineText, Canvas canvas, float left, float top, TextPaint paint, boolean fromWorkerThread) {
        String texts = danmaku.text.toString();
        String[] text = texts.split(":");
        if (danmaku.tag != null) {
            Bitmap bitmap = (Bitmap) danmaku.tag;
            canvas.drawBitmap(bitmap, null, new RectF(left, top - 30, left + 80, top + 50), paint);
        }

        canvas.drawText(text[0], left + 120, top, paint);
        canvas.drawText(text[1], left + 120, top + 50, paint);

    }

    @Override
    public void clearCaches() {

    }

    @Override
    public void drawBackground(BaseDanmaku danmaku, Canvas canvas, float left, float top) {

    }
}
