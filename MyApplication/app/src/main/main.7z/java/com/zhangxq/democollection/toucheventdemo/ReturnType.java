package com.zhangxq.democollection.toucheventdemo;

/**
 * Created by zhangxq on 16/2/1.
 */
public enum ReturnType {
    YES,
    NO,
    DEFAULT
}
